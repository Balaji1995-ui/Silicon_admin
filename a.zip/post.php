<?php require 'header.php'; ?>
<h1>hello</h1>
<?php require 'footer.php'; ?>